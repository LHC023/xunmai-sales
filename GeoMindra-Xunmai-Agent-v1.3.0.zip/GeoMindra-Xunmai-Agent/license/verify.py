#!/usr/bin/env python3
"""寻脉授权码离线校验。

用法:
  python verify.py XM1-xxxxx-yyyyy
  python verify.py XM1-xxxxx-yyyyy --json

退出码: 0 有效 / 1 无效
"""
import argparse
import base64
import datetime
import json
import pathlib
import sys

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.serialization import load_pem_public_key

HERE = pathlib.Path(__file__).resolve().parent
PUB_PATH = HERE / "public_key.pem"
REVOKED_PATH = HERE / "revoked.txt"


def b64d(text: str) -> bytes:
    return base64.urlsafe_b64decode(text + "=" * (-len(text) % 4))


def load_revoked() -> set:
    if not REVOKED_PATH.exists():
        return set()
    out = set()
    for line in REVOKED_PATH.read_text(encoding="utf-8").splitlines():
        line = line.split("#", 1)[0].strip()
        if line:
            out.add(line)
    return out


def verify(code: str) -> dict:
    code = (code or "").strip().replace(" ", "")
    parts = code.split(".")
    if len(parts) != 3 or parts[0] != "XM1":
        return {"valid": False, "reason": "format"}

    try:
        payload, sig = b64d(parts[1]), b64d(parts[2])
    except Exception:
        return {"valid": False, "reason": "encoding"}

    try:
        pub = load_pem_public_key(PUB_PATH.read_bytes())
        pub.verify(sig, b"XM1" + payload)
    except InvalidSignature:
        return {"valid": False, "reason": "signature"}
    except FileNotFoundError:
        return {"valid": False, "reason": "public_key_missing"}

    try:
        data = json.loads(payload.decode("utf-8"))
    except Exception:
        return {"valid": False, "reason": "payload"}

    exp = str(data.get("e", ""))
    today = datetime.date.today().isoformat()
    if not exp:
        return {"valid": False, "reason": "no_expiry"}
    if exp < today:
        return {"valid": False, "reason": "expired", "expires": exp}

    serial = str(data.get("s", ""))
    if serial and serial in load_revoked():
        return {"valid": False, "reason": "revoked", "serial": serial}

    return {
        "valid": True,
        "tier": data.get("t"),
        "expires": exp,
        "days_left": (datetime.date.fromisoformat(exp) - datetime.date.today()).days,
        "serial": serial,
        "holder": data.get("n", ""),
    }


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("code")
    ap.add_argument("--json", action="store_true")
    a = ap.parse_args()

    result = verify(a.code)
    if a.json:
        print(json.dumps(result, ensure_ascii=True))
    else:
        if result["valid"]:
            print(f"VALID tier={result['tier']} expires={result['expires']} "
                  f"days_left={result['days_left']} serial={result['serial']}")
        else:
            print(f"INVALID reason={result['reason']}")
    return 0 if result["valid"] else 1


if __name__ == "__main__":
    sys.exit(main())
