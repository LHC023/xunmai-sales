# 授权码模块

## 格式

```
XM1.<base64url(payload)>.<base64url(signature)>
```

payload 为紧凑 JSON：`{"t":档位,"e":到期日,"s":序号,"n":持有人}`
签名：Ed25519 对 `"XM1" + payload` 签名。

## 密钥分工

| 文件 | 位置 | 是否随包分发 |
|---|---|---|
| `private_key.pem` | `_issuer/`（包外） | **绝不** |
| `public_key.pem` | `license/`（包内） | 是，可公开 |

签发工具 `_issuer/issue.py` 与私钥一样，只在你自己机器上。

## 用法

```bash
# 签发
python _issuer/issue.py --tier personal --serial XM-0001 --days 365 --holder zhangsan

# 校验
python license/verify.py XM1.xxxxx.yyyyy
python license/verify.py XM1.xxxxx.yyyyy --json
# 退出码 0 有效 / 1 无效
```

## 吊销

`license/revoked.txt` 一行一个授权序号，`#` 后为注释。校验时先验签、再查吊销名单，命中即判无效（`reason=revoked`）。

- 用途：单个授权码泄露或退款时，只吊销该码，不影响其他客户；
- 局限：需把更新后的包（含新 `revoked.txt`）重新分发给客户才生效，已部署的旧副本不会自动同步。

## 强度说明（必须如实告知客户）

- **能防**：伪造、改到期日、改档位、批量猜码——没有私钥签不出来。
- **不能防**：用户直接修改 `verify.py` 让它永远返回有效，或删掉提示词里的门控段。

因此这是一道**合规与商务层面的门**，不是密码学意义上的 DRM。需要真正强制时，只能把推理放到服务端。

## 运维建议

- 用一张 CSV 台账记：序号 / 档位 / 持有人 / 签发日 / 到期日 / 支付流水号 / 状态；
- 一码一人，不转让；发现共享即作废该序号并重签；
- 轮换密钥会使所有旧码失效，仅在密钥泄露时执行；
- 到期前 30 天提醒续费。
